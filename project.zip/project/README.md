# How to run our solver
- All you have to is run the jupyter notebook solve all code box. We did not import any other libraries or do anything fancy, you just need to run " run_all(solve, 'inputs', 'outputs', True) "
